import pandas as pd
from pathlib import Path
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_PATH = BASE_DIR / "data" / "queue_data.csv"


def load_data():
    if not DATA_PATH.exists():
        raise FileNotFoundError(f"Dataset not found at: {DATA_PATH}")

    df = pd.read_csv(DATA_PATH)
    return df


def clean_data(df):
    df = df.copy()

    df = df.drop_duplicates()
    df = df.dropna()

    numeric_columns = [
        "hour",
        "people_waiting",
        "active_counters",
        "avg_service_time",
        "priority_customers",
        "arrival_rate",
        "waiting_time"
    ]

    for column in numeric_columns:
        df[column] = pd.to_numeric(df[column], errors="coerce")

    df = df.dropna()

    return df


def prepare_data(df):
    df = clean_data(df)

    X = df.drop("waiting_time", axis=1)
    y = df["waiting_time"]

    categorical_features = [
        "service_type",
        "day_of_week"
    ]

    numerical_features = [
        "hour",
        "people_waiting",
        "active_counters",
        "avg_service_time",
        "priority_customers",
        "arrival_rate"
    ]

    preprocessor = ColumnTransformer(
        transformers=[
            (
                "categorical",
                OneHotEncoder(handle_unknown="ignore"),
                categorical_features
            ),
            (
                "numerical",
                "passthrough",
                numerical_features
            )
        ]
    )

    return X, y, preprocessor


def split_data(X, y):
    return train_test_split(
        X,
        y,
        test_size=0.20,
        random_state=42
    )


if __name__ == "__main__":

    data = load_data()

    print("Dataset loaded successfully.")
    print(f"Number of records: {len(data)}")

    X, y, preprocessor = prepare_data(data)

    print(f"Features: {X.shape[1]}")
    print("Target: waiting_time")