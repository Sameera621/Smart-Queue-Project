import joblib
from pathlib import Path

from sklearn.pipeline import Pipeline
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

from xgboost import XGBRegressor

from data_preprocessing import (
    load_data,
    prepare_data,
    split_data
)


# ---------------------------------------------------
# PROJECT PATHS
# ---------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

MODEL_DIR = BASE_DIR / "models"

MODEL_PATH = MODEL_DIR / "waiting_time_model.pkl"


# Create models folder if it doesn't exist
MODEL_DIR.mkdir(
    parents=True,
    exist_ok=True
)


# ---------------------------------------------------
# LOAD DATA
# ---------------------------------------------------

print("Loading queue dataset...")

df = load_data()

print(f"Dataset contains {len(df)} records.")


# ---------------------------------------------------
# PREPARE DATA
# ---------------------------------------------------

X, y, preprocessor = prepare_data(df)

X_train, X_test, y_train, y_test = split_data(
    X,
    y
)

print(f"Training records: {len(X_train)}")
print(f"Testing records: {len(X_test)}")


# ---------------------------------------------------
# XGBOOST MODEL
# ---------------------------------------------------

model = XGBRegressor(
    n_estimators=300,
    learning_rate=0.05,
    max_depth=5,
    min_child_weight=2,
    subsample=0.8,
    colsample_bytree=0.8,
    objective="reg:squarederror",
    random_state=42
)


# ---------------------------------------------------
# CREATE ML PIPELINE
# ---------------------------------------------------

pipeline = Pipeline(
    steps=[
        (
            "preprocessor",
            preprocessor
        ),
        (
            "model",
            model
        )
    ]
)


# ---------------------------------------------------
# TRAIN MODEL
# ---------------------------------------------------

print("\nTraining XGBoost model...")

pipeline.fit(
    X_train,
    y_train
)

print("Model training completed.")


# ---------------------------------------------------
# PREDICTIONS
# ---------------------------------------------------

predictions = pipeline.predict(
    X_test
)


# ---------------------------------------------------
# MODEL EVALUATION
# ---------------------------------------------------

mae = mean_absolute_error(
    y_test,
    predictions
)

mse = mean_squared_error(
    y_test,
    predictions
)

rmse = mse ** 0.5

r2 = r2_score(
    y_test,
    predictions
)


print("\n-----------------------------")
print("MODEL PERFORMANCE")
print("-----------------------------")

print(f"MAE  : {mae:.2f} minutes")
print(f"RMSE : {rmse:.2f} minutes")
print(f"R²   : {r2:.2f}")


# ---------------------------------------------------
# SAVE MODEL
# ---------------------------------------------------

joblib.dump(
    pipeline,
    MODEL_PATH
)

print("\n-----------------------------")
print("MODEL SAVED")
print("-----------------------------")

print(f"Location: {MODEL_PATH}")