import pandas as pd
from pathlib import Path


# ---------------------------------------------------
# DATA PATH
# ---------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

DATA_PATH = BASE_DIR / "data" / "queue_data.csv"


# ---------------------------------------------------
# LOAD DATA
# ---------------------------------------------------

def load_queue_data():

    if not DATA_PATH.exists():

        raise FileNotFoundError(
            f"Dataset not found: {DATA_PATH}"
        )

    return pd.read_csv(
        DATA_PATH
    )


# ---------------------------------------------------
# BASIC STATISTICS
# ---------------------------------------------------

def get_basic_statistics(df):

    statistics = {

        "total_records": len(df),

        "average_waiting_time": round(
            df["waiting_time"].mean(),
            2
        ),

        "maximum_waiting_time": round(
            df["waiting_time"].max(),
            2
        ),

        "minimum_waiting_time": round(
            df["waiting_time"].min(),
            2
        ),

        "average_queue_length": round(
            df["people_waiting"].mean(),
            2
        )
    }

    return statistics


# ---------------------------------------------------
# SERVICE TYPE ANALYSIS
# ---------------------------------------------------

def get_service_type_analysis(df):

    result = (
        df.groupby("service_type")
        .agg(
            average_waiting_time=(
                "waiting_time",
                "mean"
            ),
            average_queue_length=(
                "people_waiting",
                "mean"
            ),
            total_records=(
                "waiting_time",
                "count"
            )
        )
        .reset_index()
    )

    result["average_waiting_time"] = (
        result["average_waiting_time"]
        .round(2)
    )

    result["average_queue_length"] = (
        result["average_queue_length"]
        .round(2)
    )

    return result


# ---------------------------------------------------
# DAY ANALYSIS
# ---------------------------------------------------

def get_day_analysis(df):

    result = (
        df.groupby("day_of_week")
        ["waiting_time"]
        .mean()
        .round(2)
        .reset_index()
    )

    result.columns = [
        "day_of_week",
        "average_waiting_time"
    ]

    return result


# ---------------------------------------------------
# HOURLY ANALYSIS
# ---------------------------------------------------

def get_hourly_analysis(df):

    result = (
        df.groupby("hour")
        ["waiting_time"]
        .mean()
        .round(2)
        .reset_index()
    )

    result.columns = [
        "hour",
        "average_waiting_time"
    ]

    return result


# ---------------------------------------------------
# PEAK HOUR
# ---------------------------------------------------

def get_peak_hour(df):

    hourly = get_hourly_analysis(
        df
    )

    peak_row = hourly.loc[
        hourly["average_waiting_time"].idxmax()
    ]

    return (
        int(peak_row["hour"]),
        float(
            peak_row["average_waiting_time"]
        )
    )


# ---------------------------------------------------
# CONGESTION DISTRIBUTION
# ---------------------------------------------------

def get_congestion_distribution(df):

    def classify(waiting_time):

        if waiting_time <= 10:
            return "LOW"

        elif waiting_time <= 25:
            return "MODERATE"

        return "HIGH"

    result = df.copy()

    result["congestion"] = (
        result["waiting_time"]
        .apply(classify)
    )

    return (
        result["congestion"]
        .value_counts()
        .reset_index()
    )


# ---------------------------------------------------
# MAIN TEST
# ---------------------------------------------------

if __name__ == "__main__":

    df = load_queue_data()

    statistics = get_basic_statistics(
        df
    )

    print("\nQUEUE STATISTICS")
    print("----------------")

    for key, value in statistics.items():

        print(
            f"{key}: {value}"
        )

    print("\nSERVICE TYPE ANALYSIS")
    print(
        get_service_type_analysis(df)
    )