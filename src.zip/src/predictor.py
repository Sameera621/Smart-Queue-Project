import joblib
import pandas as pd
from pathlib import Path


# ---------------------------------------------------
# MODEL PATH
# ---------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

MODEL_PATH = BASE_DIR / "models" / "waiting_time_model.pkl"


# ---------------------------------------------------
# LOAD MODEL
# ---------------------------------------------------

def load_model():

    if not MODEL_PATH.exists():

        raise FileNotFoundError(
            "Trained model not found. "
            "Please run: python src/train_model.py"
        )

    return joblib.load(MODEL_PATH)


# ---------------------------------------------------
# PREDICT WAITING TIME
# ---------------------------------------------------

def predict_waiting_time(
    service_type,
    day_of_week,
    hour,
    people_waiting,
    active_counters,
    avg_service_time,
    priority_customers,
    arrival_rate
):
    """Predict waiting time using the trained model."""

    model = load_model()

    input_data = pd.DataFrame([
        {
            "service_type": service_type,
            "day_of_week": day_of_week,
            "hour": hour,
            "people_waiting": people_waiting,
            "active_counters": active_counters,
            "avg_service_time": avg_service_time,
            "priority_customers": priority_customers,
            "arrival_rate": arrival_rate
        }
    ])

    prediction = model.predict(
        input_data
    )

    waiting_time = float(
        prediction[0]
    )

    # Waiting time cannot be negative
    waiting_time = max(
        0,
        waiting_time
    )

    return round(
        waiting_time,
        2
    )


# ---------------------------------------------------
# CONGESTION LEVEL
# ---------------------------------------------------

def get_congestion_level(waiting_time):

    if waiting_time <= 10:
        return "LOW", "🟢"

    elif waiting_time <= 25:
        return "MODERATE", "🟡"

    else:
        return "HIGH", "🔴"


# ---------------------------------------------------
# RECOMMENDATION
# ---------------------------------------------------

def get_recommendation(
    waiting_time,
    active_counters
):

    if waiting_time <= 10:

        return (
            "Queue is under control. "
            "Current counter capacity is sufficient."
        )

    elif waiting_time <= 25:

        return (
            "Queue is moderately busy. "
            "Continue monitoring the queue."
        )

    else:

        return (
            f"High congestion detected. "
            f"Consider opening an additional counter "
            f"beyond the current {active_counters}."
        )


# ---------------------------------------------------
# TEST
# ---------------------------------------------------

if __name__ == "__main__":

    result = predict_waiting_time(
        service_type="Bank",
        day_of_week="Monday",
        hour=11,
        people_waiting=35,
        active_counters=2,
        avg_service_time=5.5,
        priority_customers=3,
        arrival_rate=42
    )

    level, icon = get_congestion_level(
        result
    )

    recommendation = get_recommendation(
        result,
        2
    )

    print(
        f"Predicted waiting time: "
        f"{result} minutes"
    )

    print(
        f"Queue status: "
        f"{icon} {level}"
    )

    print(
        f"Recommendation: "
        f"{recommendation}"
    )