from datetime import datetime

try:
    from .database import SessionLocal, QueueCustomer
except ImportError:
    from database import SessionLocal, QueueCustomer

from database import (
    SessionLocal,
    QueueCustomer
)


# --------------------------------------------------
# ADD CUSTOMER TO QUEUE
# --------------------------------------------------

def add_customer(
    customer_name,
    service_type
):

    session = SessionLocal()

    try:

        # Find the latest token number
        last_customer = (
            session.query(QueueCustomer)
            .order_by(
                QueueCustomer.token_number.desc()
            )
            .first()
        )

        if last_customer:

            token_number = (
                last_customer.token_number + 1
            )

        else:

            token_number = 1

        # Create new customer
        customer = QueueCustomer(

            token_number=token_number,

            customer_name=customer_name,

            service_type=service_type,

            status="Waiting",

            joined_at=datetime.utcnow()
        )

        session.add(customer)

        session.commit()

        return token_number

    finally:

        session.close()


# --------------------------------------------------
# GET CURRENT QUEUE
# --------------------------------------------------

def get_waiting_queue():

    session = SessionLocal()

    try:

        customers = (
            session.query(QueueCustomer)
            .filter(
                QueueCustomer.status == "Waiting"
            )
            .order_by(
                QueueCustomer.joined_at.asc()
            )
            .all()
        )

        return customers

    finally:

        session.close()


# --------------------------------------------------
# GET ALL QUEUE CUSTOMERS
# --------------------------------------------------

def get_all_customers():

    session = SessionLocal()

    try:

        customers = (
            session.query(QueueCustomer)
            .order_by(
                QueueCustomer.joined_at.asc()
            )
            .all()
        )

        return customers

    finally:

        session.close()


# --------------------------------------------------
# CALL NEXT CUSTOMER
# --------------------------------------------------

def call_next_customer(counter_number):

    session = SessionLocal()

    try:

        customer = (
            session.query(QueueCustomer)
            .filter(
                QueueCustomer.status == "Waiting"
            )
            .order_by(
                QueueCustomer.joined_at.asc()
            )
            .first()
        )

        if customer is None:

            return None

        customer.status = "Serving"

        customer.counter_number = counter_number

        session.commit()

        return customer

    finally:

        session.close()


# --------------------------------------------------
# COMPLETE CUSTOMER SERVICE
# --------------------------------------------------

def complete_service(token_number):

    session = SessionLocal()

    try:

        customer = (
            session.query(QueueCustomer)
            .filter(
                QueueCustomer.token_number
                == token_number
            )
            .first()
        )

        if customer is None:

            return False

        customer.status = "Completed"

        customer.served_at = datetime.utcnow()

        session.commit()

        return True

    finally:

        session.close()


# --------------------------------------------------
# GET CUSTOMER BY TOKEN
# --------------------------------------------------

def get_customer_by_token(token_number):

    session = SessionLocal()

    try:

        customer = (
            session.query(QueueCustomer)
            .filter(
                QueueCustomer.token_number
                == token_number
            )
            .first()
        )

        return customer

    finally:

        session.close()


# --------------------------------------------------
# GET CUSTOMER POSITION
# --------------------------------------------------

def get_customer_position(token_number):

    session = SessionLocal()

    try:

        customer = (
            session.query(QueueCustomer)
            .filter(
                QueueCustomer.token_number
                == token_number
            )
            .first()
        )

        if customer is None:

            return None

        if customer.status == "Completed":

            return 0

        waiting_customers = (
            session.query(QueueCustomer)
            .filter(
                QueueCustomer.status == "Waiting"
            )
            .order_by(
                QueueCustomer.joined_at.asc()
            )
            .all()
        )

        for index, person in enumerate(
            waiting_customers,
            start=1
        ):

            if person.token_number == token_number:

                return index

        return 0

    finally:

        session.close()


# --------------------------------------------------
# COUNT WAITING CUSTOMERS
# --------------------------------------------------

def get_waiting_count():

    session = SessionLocal()

    try:

        count = (
            session.query(QueueCustomer)
            .filter(
                QueueCustomer.status == "Waiting"
            )
            .count()
        )

        return count

    finally:

        session.close()


# --------------------------------------------------
# TEST QUEUE MANAGER
# --------------------------------------------------

if __name__ == "__main__":

    print("Queue Manager Test")

    token = add_customer(
        "Test Customer",
        "Bank"
    )

    print(
        f"Customer added successfully."
    )

    print(
        f"Token Number: {token}"
    )

    print(
        f"Waiting Customers: "
        f"{get_waiting_count()}"
    )