from pathlib import Path
from datetime import datetime

from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    Float,
    String,
    DateTime
)
from sqlalchemy.orm import declarative_base, sessionmaker


# --------------------------------------------------
# DATABASE CONFIGURATION
# --------------------------------------------------

BASE_DIR = Path(__file__).resolve().parent.parent

DATABASE_PATH = BASE_DIR / "queue_database.db"

DATABASE_URL = f"sqlite:///{DATABASE_PATH}"

engine = create_engine(
    DATABASE_URL,
    connect_args={"check_same_thread": False}
)

SessionLocal = sessionmaker(bind=engine)

Base = declarative_base()


# --------------------------------------------------
# PREDICTION TABLE
# --------------------------------------------------

class Prediction(Base):

    __tablename__ = "predictions"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    service_type = Column(
        String,
        nullable=False
    )

    day_of_week = Column(
        String,
        nullable=False
    )

    hour = Column(
        Integer,
        nullable=False
    )

    people_waiting = Column(
        Integer,
        nullable=False
    )

    active_counters = Column(
        Integer,
        nullable=False
    )

    avg_service_time = Column(
        Float,
        nullable=False
    )

    priority_customers = Column(
        Integer,
        nullable=False
    )

    arrival_rate = Column(
        Float,
        nullable=False
    )

    predicted_waiting_time = Column(
        Float,
        nullable=False
    )

    congestion_level = Column(
        String,
        nullable=False
    )

    created_at = Column(
        DateTime,
        default=datetime.utcnow
    )


# --------------------------------------------------
# QUEUE CUSTOMER TABLE
# --------------------------------------------------

class QueueCustomer(Base):

    __tablename__ = "queue_customers"

    id = Column(
        Integer,
        primary_key=True,
        autoincrement=True
    )

    token_number = Column(
        Integer,
        nullable=False
    )

    customer_name = Column(
        String,
        nullable=False
    )

    service_type = Column(
        String,
        nullable=False
    )

    status = Column(
        String,
        default="Waiting",
        nullable=False
    )

    joined_at = Column(
        DateTime,
        default=datetime.utcnow
    )

    served_at = Column(
        DateTime,
        nullable=True
    )

    counter_number = Column(
        Integer,
        nullable=True
    )


# --------------------------------------------------
# CREATE DATABASE TABLES
# --------------------------------------------------

def create_database():

    Base.metadata.create_all(engine)

    print("Database tables created successfully.")


# --------------------------------------------------
# SAVE PREDICTION
# --------------------------------------------------

def save_prediction(
    service_type,
    day_of_week,
    hour,
    people_waiting,
    active_counters,
    avg_service_time,
    priority_customers,
    arrival_rate,
    predicted_waiting_time,
    congestion_level
):

    session = SessionLocal()

    try:

        prediction = Prediction(

            service_type=service_type,

            day_of_week=day_of_week,

            hour=hour,

            people_waiting=people_waiting,

            active_counters=active_counters,

            avg_service_time=avg_service_time,

            priority_customers=priority_customers,

            arrival_rate=arrival_rate,

            predicted_waiting_time=predicted_waiting_time,

            congestion_level=congestion_level
        )

        session.add(prediction)

        session.commit()

    finally:

        session.close()


# --------------------------------------------------
# GET PREDICTION HISTORY
# --------------------------------------------------

def get_prediction_history(limit=20):

    session = SessionLocal()

    try:

        records = (
            session.query(Prediction)
            .order_by(
                Prediction.created_at.desc()
            )
            .limit(limit)
            .all()
        )

        return records

    finally:

        session.close()


# --------------------------------------------------
# CREATE DATABASE WHEN FILE IS RUN DIRECTLY
# --------------------------------------------------

if __name__ == "__main__":

    create_database()

    print(
        f"Database location: {DATABASE_PATH}"
    )